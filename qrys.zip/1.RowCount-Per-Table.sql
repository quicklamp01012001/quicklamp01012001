DECLARE @sql NVARCHAR(MAX) = N'';

SELECT @sql +=
'SELECT ''' + s.name + '.' + t.name + ''' AS TableName,
        COUNT(*) AS [Rows]
 FROM ' + QUOTENAME(s.name) + '.' + QUOTENAME(t.name) + '
 UNION ALL
'
FROM sys.tables AS t
JOIN sys.schemas AS s
    ON t.schema_id = s.schema_id;


SET @sql = LEFT(@sql, LEN(@sql) - LEN(' UNION ALL ' + CHAR(13) + CHAR(10)));
SET @sql = @sql + ' ORDER BY ROWS DESC'

EXEC sp_executesql @sql;