﻿USE AdventureWorks2019_BIG;
GO

DECLARE @Target BIGINT = 4000000;
DECLARE @Current BIGINT = (SELECT COUNT(*) FROM Sales.SalesOrderDetail);

PRINT 'Starting rows = ' + CAST(@Current AS VARCHAR);

WHILE @Current < @Target
BEGIN
    DECLARE @MaxOrderID INT = (SELECT MAX(SalesOrderID) FROM Sales.SalesOrderDetail);

    INSERT INTO Sales.SalesOrderDetail
    (
        SalesOrderID,
        CarrierTrackingNumber,
        OrderQty,
        ProductID,
        SpecialOfferID,
        UnitPrice,
        UnitPriceDiscount,
        rowguid,
        ModifiedDate
        -- ❌ LineTotal removed (computed column)
    )
    SELECT
        SalesOrderID + @MaxOrderID,
        CarrierTrackingNumber,
        OrderQty,
        ProductID,
        SpecialOfferID,
        UnitPrice,
        UnitPriceDiscount,
        NEWID(),
        GETDATE()
    FROM Sales.SalesOrderDetail;

    SET @Current = (SELECT COUNT(*) FROM Sales.SalesOrderDetail);

    PRINT 'Rows now = ' + CAST(@Current AS VARCHAR);
END;

PRINT 'DONE: Reached 4M+ rows';