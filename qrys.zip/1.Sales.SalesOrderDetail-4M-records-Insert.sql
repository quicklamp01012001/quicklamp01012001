USE AdventureWorks;
GO

DECLARE @Target BIGINT = 4000000;
DECLARE @Current BIGINT;

SET @Current = (SELECT COUNT(*) FROM Sales.SalesOrderDetail);

WHILE @Current < @Target
BEGIN
    INSERT INTO Sales.SalesOrderDetail
    (
        SalesOrderID,
        CarrierTrackingNumber,
        OrderQty,
        ProductID,
        SpecialOfferID,
        UnitPrice,
        UnitPriceDiscount,
        rowguid,
        ModifiedDate,
        DataVersion
    )
    SELECT
        h.SalesOrderID,
        d.CarrierTrackingNumber,
        d.OrderQty,
        d.ProductID,
        d.SpecialOfferID,
        d.UnitPrice,
        d.UnitPriceDiscount,
        NEWID(),
        h.OrderDate,
        2
    FROM Sales.SalesOrderDetail d
    CROSS JOIN (
        SELECT TOP 1 SalesOrderID, OrderDate
        FROM Sales.SalesOrderHeader
        WHERE DataVersion = 2
        ORDER BY NEWID()
    ) h;

    SET @Current = (SELECT COUNT(*) FROM Sales.SalesOrderDetail);

    PRINT 'Detail rows = ' + CAST(@Current AS VARCHAR);
END;

