Select count(*) from Sales.SalesOrderHeader -- before 31465 after --4027520
Select count(*) from Sales.SalesOrderDetail -- before 121317 after--7764288


ALTER TABLE Sales.SalesOrderHeader ADD DataVersion INT DEFAULT 1;
ALTER TABLE Sales.SalesOrderDetail ADD DataVersion INT DEFAULT 1;


SELECT COUNT(*) FROM Sales.SalesOrderHeader;

SELECT DataVersion, COUNT(*) FROM Sales.SalesOrderHeader GROUP BY DataVersion;
SELECT DataVersion, COUNT(*) FROM Sales.SalesOrderDetail GROUP BY DataVersion;



--========= get Year and count of records
SELECT 
    DATEPART(YEAR, OrderDate) AS [Year],
    COUNT(*) AS [RecordCount]
FROM Sales.SalesOrderHeader
GROUP BY DATEPART(YEAR, OrderDate)
ORDER BY [Year];

--=========get Year and MON-YEAR, along with count of records
SELECT 
    YEAR(OrderDate) AS [Year],
    LEFT(DATENAME(MONTH, OrderDate), 3) + '-' + CAST(YEAR(OrderDate) AS VARCHAR(4)) AS [Mon-Year],
    COUNT(*) AS [RecordCount]
FROM Sales.SalesOrderHeader
GROUP BY 
    YEAR(OrderDate),
    MONTH(OrderDate),
    LEFT(DATENAME(MONTH, OrderDate), 3) + '-' + CAST(YEAR(OrderDate) AS VARCHAR(4))
ORDER BY 
    YEAR(OrderDate),
    MONTH(OrderDate);
