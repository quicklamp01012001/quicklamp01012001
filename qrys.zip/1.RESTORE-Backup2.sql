RESTORE DATABASE AdventureWorksDW2016_EXT
FROM DISK = 'C:\Backup\AdventureWorksDW2016_EXT.bak'
WITH
MOVE 'AdventureWorksDW2016_EXT_Data'
TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2016_EXT_Data.mdf',

MOVE 'AdventureWorksDW2016_EXT_Log'
TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2016_EXT_Log.ldf',

REPLACE,
RECOVERY;