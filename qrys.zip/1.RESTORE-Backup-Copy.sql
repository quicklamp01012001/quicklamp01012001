RESTORE DATABASE AdventureWorks2019_BIG
FROM DISK = 'C:\Backup\AdventureWorks2019.bak'
WITH
MOVE 'AdventureWorks2019' 
TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\AdventureWorks2019_BIG.mdf',

MOVE 'AdventureWorks2019_log'
TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\AdventureWorks2019_BIG_log.ldf',

RECOVERY, REPLACE;