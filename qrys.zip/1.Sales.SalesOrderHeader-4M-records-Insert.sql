﻿USE AdventureWorks;
GO

DECLARE @Target BIGINT = 4000000;
DECLARE @Current BIGINT;

SET @Current = (SELECT COUNT(*) FROM Sales.SalesOrderHeader);

WHILE @Current < @Target
BEGIN
    INSERT INTO Sales.SalesOrderHeader
    (
        RevisionNumber,
        OrderDate,
        DueDate,
        ShipDate,
        Status,
        OnlineOrderFlag,
        PurchaseOrderNumber,
        AccountNumber,
        CustomerID,
        SalesPersonID,
        TerritoryID,
        BillToAddressID,
        ShipToAddressID,
        ShipMethodID,
        CreditCardID,
        CreditCardApprovalCode,
        CurrencyRateID,
        SubTotal,
        TaxAmt,
        Freight,
        Comment,
        rowguid,
        ModifiedDate,
        DataVersion
    )
    SELECT
        RevisionNumber,

        -- 📊 Weighted date distribution (2014–2015 bias)
        CASE 
            WHEN ABS(CHECKSUM(NEWID())) % 100 < 65 
                THEN DATEADD(DAY, ABS(CHECKSUM(NEWID())) % 730, '2014-01-01')
            ELSE DATEADD(DAY, ABS(CHECKSUM(NEWID())) % 3650, '2010-01-01')
        END AS OrderDate,

        DATEADD(DAY, 10, GETDATE()) AS DueDate,
        DATEADD(DAY, 5, GETDATE()) AS ShipDate,

        Status,
        OnlineOrderFlag,
        PurchaseOrderNumber,
        AccountNumber,
        CustomerID,
        SalesPersonID,
        TerritoryID,
        BillToAddressID,
        ShipToAddressID,
        ShipMethodID,
        CreditCardID,
        CreditCardApprovalCode,
        CurrencyRateID,
        SubTotal,
        TaxAmt,
        Freight,
        Comment,
        NEWID(),
        GETDATE(),

        -- 🔥 NEW COLUMN
        2   -- all generated rows marked as version 2
    FROM Sales.SalesOrderHeader;

    SET @Current = (SELECT COUNT(*) FROM Sales.SalesOrderHeader);

    PRINT 'Header rows = ' + CAST(@Current AS VARCHAR);
END;

